#!/usr/bin/python
if __name__ == '__main__':
    while True:
        c = 5
