#!/usr/lib64/pypy-2.2.1/pypy
from sampler import Sample
def read_sample():
    print 'okay'

read_sample()

